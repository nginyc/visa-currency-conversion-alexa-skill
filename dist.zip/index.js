'use strict';

const handler = require('./dist/index');

exports.handler = handler.default;
